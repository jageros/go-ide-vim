package errors

func _() {
	bob.Bob() //@complete(".")
}
