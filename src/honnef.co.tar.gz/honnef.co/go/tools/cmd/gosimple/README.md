**Deprecated: gosimple has been merged into the staticcheck tool.**
