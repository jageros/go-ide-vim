package lint

import "fmt"

func AlsoMissingDoc() {
	fmt.Println("missing doc")
}
